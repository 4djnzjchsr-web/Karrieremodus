NHL MANAGER DE – EIN-DATEI-VERSION

Diese Version benötigt keinen Flutter-Install und keinen PC.

iPhone:
1. Auf github.com anmelden.
2. Neues PUBLIC Repository erstellen, z.B. nhl-manager.
3. Add file -> Upload files.
4. Diese index.html hochladen.
5. Commit changes.
6. Settings -> Pages.
7. Source: Deploy from a branch.
8. Branch: main / root.
9. Speichern.
10. Nach der Veröffentlichung die angezeigte GitHub-Pages-Adresse in Safari öffnen.
11. Safari -> Teilen -> Zum Home-Bildschirm.

Die Spielstände werden lokal im Browser gespeichert (localStorage).
Die Ein-Datei-Version funktioniert auch ohne Manifest und Service Worker.
